from setuptools import setup

setup(name='excel2jsonapi',
      version='0.1',
      description='Convert excel into json response',
      url='https://github.com/sahil-rajput/excel2jsonapi',
      author='Sahil Rajput',
      author_email='sahil.rajput.0196@gmail.com',
      license='GNU',
      packages=['excel2jsonapi'],
      zip_safe=False)